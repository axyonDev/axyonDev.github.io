#target illustrator

(function () {
    var panelFile = new File(Folder.userData + "/Axyon/AhmetPanel/AhmetPanelDynamic.jsx");
    if (!panelFile.exists) {
        alert("Axyon Illustrator paketi bulunamadı.\n\nÖnce Kurulum.command dosyasını çalıştırın veya AhmetPanelDynamic.jsx dosyasını File > Scripts > Other Script ile açın.");
        return;
    }
    $.evalFile(panelFile);
})();
