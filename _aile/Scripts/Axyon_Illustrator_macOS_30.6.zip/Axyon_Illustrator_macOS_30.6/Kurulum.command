#!/bin/bash

set -u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="$HOME/Library/Application Support/Axyon/AhmetPanel"
LAUNCHER_NAME="AxyonPanel_Baslat.jsx"

echo "Axyon Illustrator macOS kurulumu"
echo "Hedef: $INSTALL_DIR"

mkdir -p "$INSTALL_DIR"

ditto --noqtn "$SCRIPT_DIR" "$INSTALL_DIR"
chmod +x "$INSTALL_DIR/Kurulum.command" "$INSTALL_DIR/Kaldir.command" 2>/dev/null || true

installed_launchers=0

while IFS= read -r scripts_dir; do
    [ -d "$scripts_dir" ] || continue
    echo "Illustrator Scripts klasörü bulundu: $scripts_dir"
    if cp "$SCRIPT_DIR/$LAUNCHER_NAME" "$scripts_dir/$LAUNCHER_NAME" 2>/dev/null; then
        installed_launchers=$((installed_launchers + 1))
    else
        echo "Yönetici izni gerekiyor. macOS parolanızı isterse girin."
        if sudo cp "$SCRIPT_DIR/$LAUNCHER_NAME" "$scripts_dir/$LAUNCHER_NAME"; then
            installed_launchers=$((installed_launchers + 1))
        fi
    fi
done < <(find /Applications -maxdepth 5 -type d -path "*/Adobe Illustrator*/Presets.localized/*/Scripts" 2>/dev/null | sort)

echo
echo "Ana paket kuruldu."
if [ "$installed_launchers" -gt 0 ]; then
    echo "Başlatıcı $installed_launchers Illustrator Scripts klasörüne eklendi."
    echo "Illustrator'ı yeniden başlatın ve File > Scripts > AxyonPanel_Baslat menüsünü açın."
else
    echo "Illustrator Scripts klasörü otomatik bulunamadı veya yazma izni alınamadı."
    echo "File > Scripts > Other Script ile şu dosyayı seçin:"
    echo "$INSTALL_DIR/AhmetPanelDynamic.jsx"
fi

echo
read -r -p "Kapatmak için Enter'a basın..." _
