# Axyon Illustrator Script Paketi — macOS

Hedef sürüm: Adobe Illustrator 30.6 (2026). Kurucu, aynı klasör düzenini kullanan diğer güncel Illustrator sürümlerini de otomatik algılar.

## Otomatik kurulum

1. ZIP dosyasını tamamen çıkarın.
2. `Kurulum.command` dosyasına sağ tıklayıp **Aç** seçeneğini kullanın.
3. macOS engellerse **Sistem Ayarları > Gizlilik ve Güvenlik > Yine de Aç** yolunu kullanın.
4. Kurulum yönetici parolası isterse Mac oturum parolanızı girin. Yazarken karakter görünmemesi normaldir.
5. Illustrator'ı tamamen kapatıp yeniden açın.
6. **File > Scripts > AxyonPanel_Baslat** seçeneğini çalıştırın.

## Yönetici yetkisi yoksa

Kurulum ana paketi kullanıcı hesabına yine yükler. Illustrator içinden **File > Scripts > Other Script** seçeneğini açıp şu dosyayı seçin:

`~/Library/Application Support/Axyon/AhmetPanel/AhmetPanelDynamic.jsx`

Finder'da `~/Library` klasörünü açmak için **Go** menüsünü açarken Option tuşunu basılı tutabilirsiniz.

## Barkod fontu

`ScriptsEX/Barkod/ocrb10.otf` dosyasına çift tıklayın ve Font Book içinde **Install Font** seçeneğini kullanın.

## Güvenlik ve kapsam

- Kurucu yalnızca kullanıcı hesabındaki `Axyon/AhmetPanel` klasörüne ve bulunan Illustrator `Scripts` klasörlerine dosya kopyalar.
- Kaynak paketteki scriptler değiştirilmez.
- `ScriptsEX` altındaki bazı eski üçüncü taraf scriptler CS2/CS3 döneminden kalmadır. Güncel Illustrator'da çalışmayanlar olabilir; üretim dosyasında kullanmadan önce kopya belge üzerinde test edin.
- İlk denemeyi kaydedilmiş bir kopya belge üzerinde yapın.

## Kaldırma

`Kaldir.command` dosyasını çalıştırın. Kaldırma aracı işlemden önce onay ister.

## Sürüm notu

- macOS uyumluluk yaması: ExtendScript `includePath` ayırıcısı macOS'ta `:`, Windows'ta `;` kullanır.
- Panel ve script klasörleri göreli yollarla çalışır; sabit Windows sürücü yolu kullanılmaz.
- Apple Silicon ve Intel Mac desteği Illustrator'ın kendi ExtendScript çalışma ortamı üzerinden sağlanır.
