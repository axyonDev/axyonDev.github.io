#!/bin/bash

set -u

INSTALL_DIR="$HOME/Library/Application Support/Axyon/AhmetPanel"
LAUNCHER_NAME="AxyonPanel_Baslat.jsx"

echo "Axyon Illustrator macOS kaldırma aracı"
echo "Ana paket: $INSTALL_DIR"
echo
read -r -p "Paketi ve Illustrator başlatıcılarını kaldırmak istiyor musunuz? [e/H]: " answer

case "$answer" in
    e|E)
        ;;
    *)
        echo "İşlem iptal edildi."
        exit 0
        ;;
esac

while IFS= read -r scripts_dir; do
    launcher="$scripts_dir/$LAUNCHER_NAME"
    [ -f "$launcher" ] || continue
    if ! rm "$launcher" 2>/dev/null; then
        sudo rm "$launcher"
    fi
done < <(find /Applications -maxdepth 5 -type d -path "*/Adobe Illustrator*/Presets.localized/*/Scripts" 2>/dev/null | sort)

if [ -d "$INSTALL_DIR" ]; then
    rm -rf "$INSTALL_DIR"
fi

echo "Axyon Illustrator paketi kaldırıldı. Bu işlem Çöp Kutusu'ndan geri alınamaz."
